package edu.iit.hawk.cwu49;

public class NullTicket extends Ticket {
    @Override
    public boolean isNil() {
        return true;
    }
}