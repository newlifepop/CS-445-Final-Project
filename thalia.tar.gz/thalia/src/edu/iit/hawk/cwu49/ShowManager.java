package edu.iit.hawk.cwu49;

import java.util.ArrayList;
import java.util.Iterator;

public class ShowManager implements ShowInterface {
    private static ArrayList<Show> shows = new ArrayList<Show>();

    @Override
    public Show createShow(String name, String web, String date, String time, ArrayList<Section> sections) {
        Show s = new Show(name, web, date, time, sections);
        shows.add(s);
        return s;
    }

    @Override
    public Show updateShow(String showId, String name, String web, String date, String time,
            ArrayList<Section> sections) {
        int index = findShowIndexById(showId);
        if (index == -1)
            return new NullShow();

        Show s = shows.get(index);
        s.setName(name);
        s.setWeb(web);
        s.setDate(date);
        s.setTime(time);
        s.setSections(sections);
        shows.set(index, s);

        return s;
    }

    @Override
    public Show viewShow(String showId) {
        return findShowById(showId);
    }

    @Override
    public ArrayList<Show> viewAllShows() {
        return shows;
    }

    @Override
    public ArrayList<Section> viewShowSections(String showId) {
        return findShowById(showId).getSections();
    }

    @Override
    public Section viewShowSpecificSection(String showId, String sectionId) {
        return findSectionById(showId, sectionId);
    }

    @Override
    public void updateSeatAvailability(String showId, String sectionId, String chairId, boolean available) {
        int showIndex = findShowIndexById(showId);
        Show show = shows.get(showIndex);
        ArrayList<Section> sections = show.getSections();
        int sectionIndex = findSectionIndexById(sections, sectionId);
        Section section = sections.get(sectionIndex);
        ArrayList<ArrayList<Seat>> seats = section.getSeats();
        int rowIndex = findRowIndexBySeatId(section, chairId);
        ArrayList<Seat> rowSeats = seats.get(rowIndex);
        int seatIndex = findSeatIndexById(rowSeats, chairId);
        Seat seat = rowSeats.get(seatIndex);

        seat.setAvailability(available);
        rowSeats.set(seatIndex, seat);
        seats.set(rowIndex, rowSeats);
        section.setSeats(seats);
        sections.set(sectionIndex, section);
        show.setSections(sections);
        shows.set(showIndex, show);
    }

    @Override
    public boolean isAvailable(String showId, String sectionId, String chairId) {
        Section section = findSectionById(showId, sectionId);
        if (section.isNil()) return false;
        
        int rowIndex = findRowIndexBySeatId(section, chairId);
        if (rowIndex == -1) return false;

        ArrayList<Seat> rowSeats = section.getSeats().get(rowIndex);
        int seatIndex = findSeatIndexById(rowSeats, chairId);
        if (seatIndex == -1) return false;

        return rowSeats.get(seatIndex).isAvailable();
    }

    @Override
    public void deleteShow(String showId) {
        for (int i = 0; i < shows.size(); ++i) {
            if (shows.get(i).matchesId(showId)) {
                shows.remove(i);
                return;
            }
        }
    }

    private int findSeatIndexById(ArrayList<Seat> rowSeats, String chairId) {
        for (int i = 0; i < rowSeats.size(); ++i) {
            if (rowSeats.get(i).matchesId(chairId))
                return i;
        }

        return -1;
    }

    private int findRowIndexBySeatId(Section section, String chairId) {
        for (int i = 0; i < section.getSeats().size(); ++i) {
            for (Seat seat : section.getSeats().get(i))
                if (seat.matchesId(chairId))
                    return i;
        }

        return -1;
    }

    private int findSectionIndexById(ArrayList<Section> sections, String sectionId) {
        for (int i = 0; i < sections.size(); ++i) {
            if (sections.get(i).matchesId(sectionId))
                return i;
        }

        return -1;
    }

    private Section findSectionById(String showId, String sectionId) {
        ArrayList<Section> sections = findShowById(showId).getSections();
        Iterator<Section> si = sections.listIterator();
        while (si.hasNext()) {
            Section s = si.next();
            if (s.matchesId(sectionId))
                return s;
        }

        return new NullSection();
    }

    private Show findShowById(String showId) {
        Iterator<Show> si = shows.listIterator();
        while (si.hasNext()) {
            Show s = si.next();
            if (s.matchesId(showId))
                return s;
        }

        return new NullShow();
    }

    private int findShowIndexById(String showId) {
        for (int i = 0; i < shows.size(); ++i) {
            if (shows.get(i).matchesId(showId))
                return i;
        }

        return -1;
    }
}