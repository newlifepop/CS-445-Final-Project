package edu.iit.hawk.cwu49;

public class NullShow extends Show {
    @Override
    public boolean isNil() {
        return true;
    }
}