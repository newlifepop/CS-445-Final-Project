package edu.iit.hawk.cwu49;

public class NullSection extends Section {
    @Override
    public boolean isNil() {
        return true;
    }
}