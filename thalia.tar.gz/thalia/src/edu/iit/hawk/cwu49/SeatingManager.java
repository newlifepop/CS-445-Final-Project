package edu.iit.hawk.cwu49;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class SeatingManager implements SeatingInterface {
    private ArrayList<Section> sections = new ArrayList<Section>();

	@Override
	public ArrayList<Section> createDefaultTheatreLayout() {
		try {
            InputStream is = this.getClass().getResourceAsStream("./TheatreLayout.json");
            String seatsJson = fileReader(is);
            is.close();

            JSONArray sectionsArray = new JSONArray(seatsJson);

            for (int i = 0; i < sectionsArray.length(); ++i) {
                JSONObject sectionObject = sectionsArray.getJSONObject(i);
                
                String sectionId = sectionObject.getString("sid");
                String sectionName = sectionObject.getString("section_name");
                JSONArray seatingArray = sectionObject.getJSONArray("seating");

                ArrayList<ArrayList<Seat>> seats = new ArrayList<ArrayList<Seat>>();

                for (int j = 0; j < seatingArray.length(); ++j) {
                    JSONObject seatingObject = seatingArray.getJSONObject(j);
                    ArrayList<Seat> rowSeats = new ArrayList<Seat>();
                    JSONArray seatsArray = seatingObject.getJSONArray("seats");
                    for (int k = 0; k < seatsArray.length(); ++k) {
                        String seatNumber = seatsArray.getString(k);
                        String charId = HelperFunctions.getUniqueChairId();
                        rowSeats.add(new Seat(charId, seatNumber, true));
                    }

                    seats.add(rowSeats);
                }

                sections.add(new Section(sectionId, sectionName, 0, seats));
            }

            return sections;
        } catch (Exception e) {
            return null;
        }
    }
    
    @Override
    public ArrayList<Section> getTheatreLayout() {
        return sections;
    }

	@Override
	public ArrayList<Seat> getAllSeats() {
        ArrayList<Seat> seats = new ArrayList<Seat>();
        for (Section section: sections) {
            ArrayList<ArrayList<Seat>> sectionSeats = section.getSeats();
            for (ArrayList<Seat> rowSeats : sectionSeats) {
                for (Seat seat : rowSeats) {
                    seats.add(seat);
                }
            }
        }
        
        return seats;
    }

    @Override
    public Section getSection(String sectionId) {
        for (Section section : sections) {
            if (section.matchesId(sectionId))
                return section;
        }

        return new NullSection();
    }

    @Override
    public String getSectionName(String sectionId) {
        for (Section section : sections) {
            if (section.matchesId(sectionId))
                return section.getSectionName();
        }

        return null;
    }

    @Override
    public ArrayList<ArrayList<Seat>> getSectionSeats(String sectionId) {
        Section section = getSection(sectionId);
        if (section.isNil()) return null;
        return section.getSeats();
    }

    @Override
    public ArrayList<Seat> findContiguousSeats(Section section, int count, String startingSeatChairId) {
        if (count <= 0) return null;

        // If startingSeatChairId is valid, then find the row of seats
        // where chair with startingSeatChairId is located
        if (startingSeatChairId != null && startingSeatChairId != "") {
            ArrayList<Seat> rowSeats = getRowSeats(section, startingSeatChairId);
            if (rowSeats == null) return null;
            return getContiguousSeats(rowSeats, count, startingSeatChairId);
        }

        // If startingSeatCharId is not valid, e.g. not specified, then
        // find "count" many contiguous seat and return
        for (int i = 0; i < section.getSeats().size(); ++i) {
            ArrayList<Seat> rowSeats = section.getSeats().get(i);
            ArrayList<Seat> result = getContiguousSeats(rowSeats, count, startingSeatChairId);
            if (result != null) return result;
        }

        return null;
    }

    @Override
    public int getRowNumber(Section section, Seat seat) {
        for (int i = 0; i < section.getSeats().size(); ++i) {
            ArrayList<Seat> rowSeats = section.getSeats().get(i);
            for (int j = 0; j < rowSeats.size(); ++j) {
                if (rowSeats.get(j).matchesId(seat.getCharId()))
                    return i + 1;
            }
        }

        return -1;
    }

    // Get "count" many contiguous seats in the same row
    private static ArrayList<Seat> getContiguousSeats(ArrayList<Seat> rowSeats, int count, String startingSeatChairId) {
        if (startingSeatChairId != null && startingSeatChairId != "") {
            int index = indexOfSeat(rowSeats, startingSeatChairId);
            return getSeats(rowSeats, count, index);
        }

        for (int i = 0; i < rowSeats.size(); ++i) {
            ArrayList<Seat> result = getSeats(rowSeats, count, i);
            if (result != null) return result;
        }

        return null;
    }

    public static int indexOfSeat(ArrayList<Seat> rowSeats, String startingSeatChairId) {
        for (int i = 0; i < rowSeats.size(); ++i) {
            if (rowSeats.get(i).matchesId(startingSeatChairId))
                return i;
        }

        return 0;
    }

    // Find "count" many contiguous seats starting from "staringSeatChairId"
    private static ArrayList<Seat> getSeats(ArrayList<Seat> rowSeats, int count, int startingSeatChairIndex) {
        ArrayList<Seat> result = new ArrayList<Seat>();
        for (int i = startingSeatChairIndex; result.size() < count; ++i) {
            if (i >= rowSeats.size()) return null;

            Seat currentSeat = rowSeats.get(i);
            if (!currentSeat.isAvailable()) return null;
            result.add(currentSeat);
        }

        return result;
    }

    // Get the row of seats where the specified seat is located
    private static ArrayList<Seat> getRowSeats(Section section, String startingSeatChairId) {
        ArrayList<ArrayList<Seat>> sectionSeats = section.getSeats();
        for (ArrayList<Seat> rowSeats : sectionSeats) {
            for (Seat s : rowSeats) {
                if (s.matchesId(startingSeatChairId)) {
                    return rowSeats;
                }
            }
        }

        return null;
    }
    
    private static String fileReader(InputStream is) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null)
                sb.append(line).append('\n');

            reader.close();

            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}