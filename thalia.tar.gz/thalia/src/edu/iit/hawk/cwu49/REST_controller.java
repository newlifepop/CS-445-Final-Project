package edu.iit.hawk.cwu49;

import com.google.gson.stream.JsonWriter;

import java.io.BufferedWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import org.json.JSONArray;
import org.json.JSONObject;

@Path("/")
public class REST_controller {
    private SeatingInterface seatingManager = new SeatingManager();
    private ShowInterface showManager = new ShowManager();
    private TicketInterface ticketManager = new TicketManager();
    private OrderInterface orderManager = new OrderManager();
    private DonationInterface donationRequestManager = new DonationManager();

    @Path("/shows")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response createShow(@Context UriInfo uriInfo, String json) {
        try {
            JSONObject showObject = new JSONObject(json);
            if (!showObject.has("show_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find show_info");
            } else if (!showObject.has("seating_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find seating_info");
            }

            JSONObject showInfoJson = showObject.getJSONObject("show_info");
            JSONArray seatingInfoArray = showObject.getJSONArray("seating_info");

            if (!showInfoJson.has("name"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find name");
            else if (!showInfoJson.has("date"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find date");
            else if (!showInfoJson.has("time"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find time");

            String name = showInfoJson.getString("name");
            String date = showInfoJson.getString("date");
            if (!HelperFunctions.validateDateFormat(date)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Date is not in YYYY-MM-DD format");
            }

            String time = showInfoJson.getString("time");
            if (!HelperFunctions.validateTimeFormat(time)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Time is not in HH:MM format");
            }

            String web = null;
            if (showInfoJson.has("web"))
                web = showInfoJson.getString("web");

            if (web != null && !HelperFunctions.validateWebFormat(web)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Web is not a valid URL");
            }

            ArrayList<Section> sections = new ArrayList<Section>();
            for (int i = 0; i < seatingInfoArray.length(); ++i) {
                JSONObject sectioObject = seatingInfoArray.getJSONObject(i);
                if (!sectioObject.has("sid"))
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find sid for section #" + (i + 1));
                if (!sectioObject.has("price"))
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find price for section #" + (i + 1));

                String sectionId = sectioObject.getString("sid");
                String sectionName = seatingManager.getSectionName(sectionId);
                if (sectionName == null) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find section name for section #" + sectionId);
                }
                int price = sectioObject.getInt("price");

                ArrayList<ArrayList<Seat>> sectionSeats = seatingManager.getSectionSeats(sectionId);
                if (sectionSeats == null) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find section seats for section #" + sectionId);
                }
                sections.add(new Section(sectionId, sectionName, price, sectionSeats));
            }

            Show newShow = showManager.createShow(name, web, date, time, sections);
            String showId = newShow.getShowId();

            UriBuilder builder = uriInfo.getAbsolutePathBuilder();
            builder.path(showId);

            String s = "{\"wid\":" + showId + "}";
            return Response.created(builder.build()).entity(HelperFunctions.prettyJson(s)).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}")
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateShow(@PathParam("wid") String showId, String json) {
        try {
            JSONObject showObject = new JSONObject(json);
            if (!showObject.has("show_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find show_info");
            } else if (!showObject.has("seating_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find seating_info");
            }

            JSONObject showInfoJson = showObject.getJSONObject("show_info");
            JSONArray seatingInfoArray = showObject.getJSONArray("seating_info");

            if (!showInfoJson.has("name"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find name");
            else if (!showInfoJson.has("date"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find date");
            else if (!showInfoJson.has("time"))
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find time");

            String name = showInfoJson.getString("name");
            String date = showInfoJson.getString("date");
            if (!HelperFunctions.validateDateFormat(date)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Date is not in YYYY-MM-DD format");
            }

            String time = showInfoJson.getString("time");
            if (!HelperFunctions.validateTimeFormat(time)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Time is not in HH:MM format");
            }

            String web = null;
            if (showInfoJson.has("web"))
                web = showInfoJson.getString("web");

            if (web != null && !HelperFunctions.validateWebFormat(web)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Web is not a valid URL");
            }

            ArrayList<Section> sections = new ArrayList<Section>();
            for (int i = 0; i < seatingInfoArray.length(); ++i) {
                JSONObject sectioObject = seatingInfoArray.getJSONObject(i);
                if (!sectioObject.has("sid"))
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find sid for section #" + (i + 1));
                if (!sectioObject.has("price"))
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find price for section #" + (i + 1));

                String sectionId = sectioObject.getString("sid");
                String sectionName = seatingManager.getSectionName(sectionId);
                if (sectionName == null) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find section name for section #" + sectionId);
                }
                int price = sectioObject.getInt("price");

                ArrayList<ArrayList<Seat>> sectionSeats = seatingManager.getSectionSeats(sectionId);
                if (sectionSeats == null) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find section seats for section #" + sectionId);
                }
                sections.add(new Section(sectionId, sectionName, price, sectionSeats));
            }

            Show updatedShow = showManager.updateShow(showId, name, web, date, time, sections);
            if (updatedShow.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);
            }

            return Response.status(Response.Status.OK).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewShow(@PathParam("wid") String showId) {
        try {
            Show s = showManager.viewShow(showId);

            if (s.isNil())
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);

            String name = s.getName();
            String web = s.getWeb();
            String date = s.getDate();
            String time = s.getTime();
            ArrayList<Section> sections = s.getSections();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(new BufferedWriter(sw));
            writer.beginObject();
            HelperFunctions.writeShowInfo(writer, showId, name, web, date, time);
            HelperFunctions.writeSeatingsInfo(writer, sections);
            writer.endObject();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewAllShows() {
        try {
            ArrayList<Show> showList = showManager.viewAllShows();
            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(new BufferedWriter(sw));

            writer.beginArray();

            for (Show s : showList) {
                String showId = s.getShowId();
                String name = s.getName();
                String web = s.getWeb();
                String date = s.getDate();
                String time = s.getTime();

                writer.beginObject();
                HelperFunctions.writeShowInfo(writer, showId, name, web, date, time);
                writer.endObject();
            }

            writer.endArray();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}")
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteShow(@PathParam("wid") String showId) {
        try {
            Show targetShow = showManager.viewShow(showId);
            if (targetShow.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);
            }

            ticketManager.deleteTickets(showId);
            orderManager.deleteOrders(showId);
            showManager.deleteShow(showId);

            String s = "{\"wid\":" + showId + "}";
            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(s)).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}/sections")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewShowSections(@PathParam("wid") String showId) {
        try {
            ArrayList<Section> sections = showManager.viewShowSections(showId);
            if (sections == null) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);
            }

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(new BufferedWriter(sw));

            writer.beginArray();

            for (Section s : sections) {
                String sectionId = s.getSectionId();
                String sectionName = s.getSectionName();
                int price = s.getPrice();

                writer.beginObject();
                HelperFunctions.writeSectionInfo(writer, sectionId, sectionName, price);
                writer.endObject();
            }

            writer.endArray();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}/sections/{sid}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewShowSpecificSection(@PathParam("wid") String showId, @PathParam("sid") String sectionId) {
        try {
            Show s = showManager.viewShow(showId);
            if (s.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);
            }

            Section section = showManager.viewShowSpecificSection(showId, sectionId);
            if (section.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find section #" + sectionId);
            }

            String name = s.getName();
            String web = s.getWeb();
            String date = s.getDate();
            String time = s.getTime();

            String sectionName = section.getSectionName();
            int price = section.getPrice();
            ArrayList<ArrayList<Seat>> seats = section.getSeats();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(new BufferedWriter(sw));

            writer.beginObject();
            HelperFunctions.writeShowInfo(writer, showId, name, web, date, time);
            HelperFunctions.writeSectionInfo(writer, sectionId, sectionName, price);
            HelperFunctions.writeSectionSeatsInfo(writer, seats);
            writer.endObject();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}/donations")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response subscribeToTickets(@Context UriInfo uriInfo, @PathParam("wid") String showId, String json) {
        try {
            JSONObject donationObject = new JSONObject(json);
            if (!donationObject.has("wid")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find wid");
            } else if (!donationObject.has("count")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find count");
            } else if (!donationObject.has("patron_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find patron_info");
            }

            if (!donationObject.getString("wid").equals(showId)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "wids do not match");
            }

            int count = donationObject.getInt("count");
            JSONObject patronObject = donationObject.getJSONObject("patron_info");
            if (!patronObject.has("name")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find name");
            } else if (!patronObject.has("phone")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find phone");
            } else if (!patronObject.has("email")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find email");
            } else if (!patronObject.has("billing_address")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find billing_address");
            } else if (!patronObject.has("cc_number")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find cc_number");
            } else if (!patronObject.has("cc_expiration_date")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find cc_expiration_date");
            }

            String name = patronObject.getString("name");
            String phone = patronObject.getString("phone");
            String email = patronObject.getString("email");
            String billingAddress = patronObject.getString("billing_address");
            String ccNumber = patronObject.getString("cc_number");
            String ccExpirationDate = patronObject.getString("cc_expiration_date");

            if (!HelperFunctions.validatePhoneNumber(phone)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Phone number is not in xxx-xxx-xxxx format or contains illegal characters");
            } else if (!HelperFunctions.validateCreditCardNumber(ccNumber)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Credit Card number is not in xxxxxxxxxxxxxxxx format or contains illegal characters");
            } else if (!HelperFunctions.validateExpirationDate(ccExpirationDate)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Expiration date is not in MM/YY format or has already expired");
            }

            Show show = showManager.viewShow(showId);
            if (show.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find show #" + showId);
            }

            CreditCard creditCard = new CreditCard(ccNumber, ccExpirationDate, billingAddress);
            Patron patron = new Patron(name, phone, email, creditCard);
            DonationRequest request = donationRequestManager.createDonationRequest(showId, count, patron);

            String donationId = request.getDonationId();
            UriBuilder builder = uriInfo.getAbsolutePathBuilder();
            builder.path(donationId);

            String s = "{\"did\":" + donationId + "}";
            return Response.created(builder.build()).entity(HelperFunctions.prettyJson(s)).build();

        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/shows/{wid}/donations/{did}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewStatus(@PathParam("wid") String showId, @PathParam("did") String donationId) {
        try {
            DonationRequest request = donationRequestManager.viewDonationRequest(donationId);
            if (request.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find donation #" + donationId);
            } else if (!request.getShowId().equals(showId)) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Donation #" + donationId + " is not a request for show #" + showId);
            }

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            HelperFunctions.writeDonationRequestInfo(writer, request);
            writer.endObject();
            writer.flush();
            writer.close();
            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/seating")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response requestSeatsAuto(@Context UriInfo info, @QueryParam("show") String showId,
            @QueryParam("section") String sectionId, @QueryParam("count") int count) {
        try {
            if (showId == null || showId == "" || sectionId == null || sectionId == "" || count == 0) {
                StringWriter sw = new StringWriter();
                JsonWriter writer = new JsonWriter(sw);

                writer.beginArray();
                for (Section s : seatingManager.getTheatreLayout()) {
                    writer.beginObject();
                    writer.name("sid").value(s.getSectionId());
                    writer.name("section_name").value(s.getSectionName());
                    writer.endObject();
                }
                writer.endArray();
                writer.flush();
                writer.close();

                return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
            }

            String startingSeatChairId = info.getQueryParameters().getFirst("starting_seat_id");

            Show show = showManager.viewShow(showId);
            if (show.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find show #" + showId);
            }

            Section section = showManager.viewShowSpecificSection(showId, sectionId);
            if (section.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find section #" + sectionId);
            }

            String name = show.getName();
            String web = show.getWeb();
            String date = show.getDate();
            String time = show.getTime();
            String sectionName = "";
            String status = "";

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            HelperFunctions.writeShowInfo(writer, showId, name, web, date, time);

            ArrayList<ArrayList<Seat>> sectionSeats = section.getSeats();
            if (sectionSeats == null || sectionSeats.size() == 0) {
                sectionName = "NOT_FOUND";
                status = "Error: Unable to find section #" + sectionId;
                HelperFunctions.writeErrorTicket(writer, sectionId, sectionName, startingSeatChairId, status);
                writer.endObject();
                return Response.status(Response.Status.NOT_FOUND).entity(HelperFunctions.prettyJson(sw.toString()))
                        .build();
            }

            sectionName = section.getSectionName();
            ArrayList<Seat> contiguoutsSeats = seatingManager.findContiguousSeats(section, count, startingSeatChairId);
            if (contiguoutsSeats == null) {
                status = "Error: Unable to find " + count + " contiguouts seats";
                HelperFunctions.writeErrorTicket(writer, sectionId, sectionName, startingSeatChairId, status);
                writer.endObject();
                return Response.status(Response.Status.NOT_FOUND).entity(HelperFunctions.prettyJson(sw.toString()))
                        .build();
            }

            status = "ok";
            int row = seatingManager.getRowNumber(section, contiguoutsSeats.get(0));
            int totalAmount = section.getPrice() * contiguoutsSeats.size();
            HelperFunctions.writeTicketInfo(writer, sectionId, sectionName, startingSeatChairId, status, totalAmount,
                    row, contiguoutsSeats);
            writer.endObject();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/seating/{sid}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewSpecificSection(@PathParam("sid") String sectionId) {
        try {
            Section section = seatingManager.getSection(sectionId);
            if (section.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find section #" + sectionId);
            }

            ArrayList<ArrayList<Seat>> seats = section.getSeats();
            String sectionName = section.getSectionName();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            writer.name("sid").value(sectionId);
            writer.name("section_name").value(sectionName);
            HelperFunctions.writeSectionSeatsInfoRaw(writer, seats);
            writer.endObject();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/orders")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response createOrder(@Context UriInfo uriInfo, String json) {
        try {
            JSONObject orderObject = new JSONObject(json);
            if (!orderObject.has("wid")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find wid");
            } else if (!orderObject.has("sid")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find sid");
            } else if (!orderObject.has("seats")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find seats");
            } else if (!orderObject.has("patron_info")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find patron_info");
            }

            String showId = orderObject.getString("wid");
            Show show = showManager.viewShow(showId);
            if (show.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find show #" + showId);
            }

            String sectionId = orderObject.getString("sid");
            Section section = showManager.viewShowSpecificSection(showId, sectionId);
            if (section.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "This show does not offer section #" + sectionId);
            }

            ArrayList<Seat> seats = new ArrayList<Seat>();
            JSONArray seatsArray = orderObject.getJSONArray("seats");
            for (int i = 0; i < seatsArray.length(); ++i) {
                JSONObject seatObject = seatsArray.getJSONObject(i);
                if (!seatObject.has("cid")) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find cid of seat #" + (i + 1));
                } else if (!seatObject.has("seat")) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find seat number of seat #" + (i + 1));
                }

                String chairId = seatObject.getString("cid");
                if (!showManager.isAvailable(showId, sectionId, chairId)) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Seat #" + chairId + " is sold or not offered for this show");
                }

                String seatNumber = seatObject.getString("seat");
                seats.add(new Seat(chairId, seatNumber, false));
            }

            JSONObject patronObject = orderObject.getJSONObject("patron_info");
            if (!patronObject.has("name")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find name");
            } else if (!patronObject.has("phone")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find phone");
            } else if (!patronObject.has("email")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find email");
            } else if (!patronObject.has("billing_address")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find billing_address");
            } else if (!patronObject.has("cc_number")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find cc_number");
            } else if (!patronObject.has("cc_expiration_date")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Unable to find cc_expiration_date");
            }

            String name = patronObject.getString("name");
            String phone = patronObject.getString("phone");
            if (!HelperFunctions.validatePhoneNumber(phone)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Phone number is not in xxx-xxx-xxxx format or contains illegal characters");
            }
            String email = patronObject.getString("email");
            String billingAddress = patronObject.getString("billing_address");
            String ccNumber = patronObject.getString("cc_number");
            if (!HelperFunctions.validateCreditCardNumber(ccNumber)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Credit card number is not in xxxxxxxxxxxxxxxx format or contains illegal characters");
            }
            String ccExpirationDate = patronObject.getString("cc_expiration_date");
            if (!HelperFunctions.validateExpirationDate(ccExpirationDate)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Credit card expiration date is not in MM/YY format or has already expired");
            }

            Patron patron = new Patron(name, phone, email, new CreditCard(ccNumber, ccExpirationDate, billingAddress));
            ArrayList<Ticket> tickets = new ArrayList<Ticket>();
            for (int i = 0; i < seats.size(); ++i) {
                Ticket newTicket = ticketManager.addTicket(section.getPrice(), false, showId, patron, sectionId,
                        seats.get(i));
                tickets.add(newTicket);
                showManager.updateSeatAvailability(showId, sectionId, seats.get(i).getCharId(), false);
            }

            int totalAmount = seats.size() * section.getPrice();
            Order newOrder = orderManager.createOrder(showId, new Date(), totalAmount, tickets);

            String orderId = newOrder.getOrderId();
            Date dateOrdered = newOrder.getDate();
            String formattedDate = HelperFunctions.formatOrderDate(dateOrdered);

            String showName = show.getName();
            String showWeb = show.getWeb();
            String showDate = show.getDate();
            String showTime = show.getTime();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            HelperFunctions.writeOrderInfo(writer, orderId, showId, showName, showWeb, showDate, showTime,
                    formattedDate, totalAmount);
            writer.name("tickets").beginArray();
            for (Ticket t : tickets) {
                writer.value(t.getTicketId());
            }
            writer.endArray();
            writer.endObject();
            writer.flush();
            writer.close();

            UriBuilder builder = uriInfo.getAbsolutePathBuilder();
            builder.path(orderId);
            return Response.created(builder.build()).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/orders")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewAllOrders(@QueryParam("start_date") String startDate, @QueryParam("end_date") String endDate) {
        try {
            ArrayList<Order> result = new ArrayList<Order>();
            if (startDate != null && startDate != "" && endDate != null && endDate != "") {
                // Check if startDate and endDate are in correct format
                if (!HelperFunctions.validateSearchDateFormat(startDate)) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "start date is in wrong format");
                } else if (!HelperFunctions.validateSearchDateFormat(endDate)) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "end date is in wrong format");
                }

                endDate = Integer.toString(Integer.parseInt(endDate) + 1);
                // Build Date object of start and end date
                Date startdate = HelperFunctions.buildDate(startDate);
                Date enddate = HelperFunctions.buildDate(endDate);
                result = orderManager.viewOrderByDate(startdate, enddate);
            } else {
                result = orderManager.viewAllOrders();
            }

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);

            writer.beginArray();
            for (Order order : result) {
                String orderId = order.getOrderId();
                String showId = order.getShowId();
                Show show = showManager.viewShow(showId);
                String showName = show.getName();
                String showWeb = show.getWeb();
                String showDate = show.getDate();
                String showTime = show.getTime();
                String formattedDate = HelperFunctions.formatOrderDate(order.getDate());
                int totalAmount = order.getAmount();
                int numberOfTickets = order.getTickets().size();

                Patron patron = order.getTickets().get(0).getPatron();
                CreditCard card = patron.getCreditCard();

                String patronName = patron.getName();
                String patronPhone = patron.getPhone();
                String patronEmail = patron.getEmail();
                String cardAddress = card.getBillingAddress();
                String cardNumber = card.getCardNumber();
                String expirationDate = card.getExpirationDate();

                writer.beginObject();
                HelperFunctions.writeOrderInfo(writer, orderId, showId, showName, showWeb, showDate, showTime,
                        formattedDate, totalAmount);
                writer.name("number_of_tickets").value(numberOfTickets);
                HelperFunctions.writePatronInfo(writer, patronName, patronPhone, patronEmail, cardAddress, cardNumber,
                        expirationDate);
                writer.endObject();
            }
            writer.endArray();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/orders/{oid}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewOrderByOrderId(@PathParam("oid") String orderId) {
        try {
            Order order = orderManager.viewOrder(orderId);
            if (order.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find order #" + orderId);
            }
            String showId = order.getShowId();
            Show show = showManager.viewShow(showId);

            Date dateOrdered = order.getDate();
            String formattedDate = HelperFunctions.formatOrderDate(dateOrdered);

            String showName = show.getName();
            String showWeb = show.getWeb();
            String showDate = show.getDate();
            String showTime = show.getTime();

            int totalAmount = order.getAmount();

            ArrayList<Ticket> tickets = order.getTickets();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            HelperFunctions.writeOrderInfo(writer, orderId, showId, showName, showWeb, showDate, showTime,
                    formattedDate, totalAmount);
            writer.name("tickets").beginArray();
            for (Ticket ticket : tickets) {
                String ticketId = ticket.getTicketId();
                String status = ticket.isUsed() ? "used" : "open";

                writer.beginObject();
                writer.name("tid").value(ticketId);
                writer.name("status").value(status);
                writer.endObject();
            }
            writer.endArray();
            writer.endObject();
            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/orders/{oid}")
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTicket(@PathParam("oid") String orderId) {
        try {
            Order order = orderManager.viewOrder(orderId);
            if (order.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND, "Unable to find order #" + orderId);
            }

            for (Ticket t : order.getTickets()) {
                ticketManager.deleteTicket(t.getTicketId());
            }
            orderManager.deleteOrder(order.getOrderId());

            String s = "{\"oid\":" + orderId + "}";

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(s)).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/tickets/{tid}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response viewTicket(@PathParam("tid") String ticketId) {
        try {
            Ticket ticket = ticketManager.viewTicket(ticketId);
            if (ticket.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find ticket #" + ticketId);
            }

            int price = ticket.getPrice();
            boolean used = ticket.isUsed();
            String showId = ticket.getShowId();
            Show show = showManager.viewShow(showId);
            String showName = show.getName();
            String showWeb = show.getWeb();
            String showDate = show.getDate();
            String showTime = show.getTime();
            Patron patron = ticket.getPatron();
            CreditCard card = patron.getCreditCard();
            Seat seat = ticket.getSeat();
            String sectionId = ticket.getSectionId();
            Section section = seatingManager.getSection(sectionId);

            String patronName = patron.getName();
            String patronPhone = patron.getPhone();
            String patronEmail = patron.getEmail();
            String cardAddress = card.getBillingAddress();
            String cardNumber = card.getCardNumber();
            String expirationDate = card.getExpirationDate();

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);

            writer.beginObject();
            HelperFunctions.writeTicketInfoRaw(writer, ticketId, price, used);
            HelperFunctions.writeShowInfo(writer, showId, showName, showWeb, showDate, showTime);
            HelperFunctions.writePatronInfo(writer, patronName, patronPhone, patronEmail, cardAddress, cardNumber,
                    expirationDate);
            writer.name("seating").beginArray();
            writer.beginObject();
            writer.name("row").value(Integer.toString(seatingManager.getRowNumber(section, seat)));
            writer.name("seats").beginArray();
            writer.beginObject();
            writer.name("cid").value(seat.getCharId());
            writer.name("seat").value(seat.getSeatNumber());
            writer.endObject();
            writer.endArray();
            writer.endObject();
            writer.endArray();
            writer.endObject();

            writer.flush();
            writer.close();

            return Response.status(Response.Status.OK).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/tickets/{tid}")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response scanTicket(@Context UriInfo uriInfo, @PathParam("tid") String ticketId, String json) {
        try {

            Ticket ticket = ticketManager.viewTicket(ticketId);
            if (ticket.isNil()) {
                return HelperFunctions.returnErrorResponse(Response.Status.NOT_FOUND,
                        "Unable to find ticket #" + ticketId);
            }

            JSONObject ticketObject = new JSONObject(json);
            if (!ticketObject.has("tid")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find tid");
            } else if (!ticketObject.has("status")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find status");
            }

            if (!ticketObject.getString("tid").equals(ticketId)) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Ticket IDs do not match");
            }

            String status = ticketObject.getString("status");
            boolean used = false;
            if (status.equals("used")) {
                used = true;
            } else if (status.equals("open")) {
                used = false;
            } else {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                        "Invalid status code: " + status);
            }

            ticketManager.scanTicket(ticketId);
            orderManager.updateTicketStatus(ticketId, used);

            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonWriter(sw);
            writer.beginObject();
            writer.name("tid").value(ticketId);
            writer.name("status").value(used ? "used" : "false");
            writer.endObject();
            writer.flush();
            writer.close();

            UriBuilder builder = uriInfo.getAbsolutePathBuilder();
            builder.path(ticketId);
            return Response.ok(builder.build()).entity(HelperFunctions.prettyJson(sw.toString())).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @Path("/tickets/donations")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response donateTickets(@Context UriInfo uriInfo, String json) {
        try {
            JSONObject object = new JSONObject(json);
            if (!object.has("tickets")) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "Unable to find tickets");
            }

            ArrayList<Ticket> tickets = new ArrayList<Ticket>();
            JSONArray ticketsArray = object.getJSONArray("tickets");
            for (int i = 0; i < ticketsArray.length(); ++i) {
                String ticketId = ticketsArray.getString(i);
                Ticket ticket = ticketManager.viewTicket(ticketId);
                if (ticket.isNil()) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Unable to find ticket #" + ticketId);
                }

                if (ticket.isUsed()) {
                    return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST,
                            "Ticket #" + ticketId + " has already been used");
                }

                tickets.add(ticket);
            }

            if (tickets.size() == 0) {
                return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, "No ticket found");
            }

            ticketManager.donateTickets(tickets);

            UriBuilder builder = uriInfo.getAbsolutePathBuilder();
            builder.path(tickets.get(0).getTicketId());
            return Response.created(builder.build()).build();
        } catch (Exception e) {
            return HelperFunctions.returnErrorResponse(Response.Status.BAD_REQUEST, e.toString());
        }
    }

    @PostConstruct
    public void postConstruct() {
        seatingManager.createDefaultTheatreLayout();
    }
}