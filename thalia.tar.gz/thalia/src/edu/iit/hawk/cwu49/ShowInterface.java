package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public interface ShowInterface {
    Show createShow(String name, String web, String date, String time, ArrayList<Section> sections);

    Show updateShow(String showId, String name, String web, String date, String time, ArrayList<Section> sections);

    Show viewShow(String showId);

    ArrayList<Show> viewAllShows();

    // Optional: Show deleteShow(String showId);

    ArrayList<Section> viewShowSections(String showId);

    Section viewShowSpecificSection(String showId, String sectionId);

    void updateSeatAvailability(String showId, String sectionId, String chairId, boolean isAvailable);

    boolean isAvailable(String showId, String sectionId, String chairId);

    void deleteShow(String showId);
}