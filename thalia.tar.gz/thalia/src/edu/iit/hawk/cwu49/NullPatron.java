package edu.iit.hawk.cwu49;

public class NullPatron extends Patron {
    @Override
    public boolean isNil() {
        return true;
    }
}