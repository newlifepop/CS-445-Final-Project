package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public interface TicketInterface {
    Ticket addTicket(int price, boolean used, String showId, Patron patron, String sectionId, Seat seat);
    ArrayList<Ticket> viewAllTickets();
    Ticket viewTicket(String ticketId);
    Ticket scanTicket(String ticketId);
    ArrayList<Ticket> donateTickets(ArrayList<Ticket> tickets);
}