package edu.iit.hawk.cwu49;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import javax.ws.rs.core.Response;

public class HelperFunctions {
    static AtomicInteger atomicShowInteger = new AtomicInteger();
    static AtomicInteger atomicChairId = new AtomicInteger();
    static AtomicInteger atomicOrderId = new AtomicInteger();
    static AtomicInteger atomicTicketId = new AtomicInteger();
    static AtomicInteger atomicDonationId = new AtomicInteger();
    static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    static Gson gson = new GsonBuilder().setPrettyPrinting().create();
    static Calendar calendar = Calendar.getInstance();

    public static String getUniqueShowId() {
        return Integer.toString(atomicShowInteger.incrementAndGet());
    }

    public static String getUniqueChairId() {
        return Integer.toString(atomicChairId.incrementAndGet() % 103 + 100);
    }

    public static String getUniqueOrderId() {
        return Integer.toString(atomicOrderId.incrementAndGet() + 200);
    }

    public static String getUniqueTicketId() {
        return Integer.toString(atomicTicketId.incrementAndGet() + 300);
    }

    public static String getUniqueDonationId() {
        return Integer.toString(atomicDonationId.incrementAndGet() + 400);
    }

    // Check if date is in "YYYY-MM-DD" form
    public static boolean validateDateFormat(String date) {
        if (date == null || !date.matches("\\d{4}-[0-1]\\d-[0-3]\\d")) {
            return false;
        }

        dateFormatter.setLenient(false);
        try {
            dateFormatter.parse(date);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Check if date is in "YYYYMMDD" format
    public static boolean validateSearchDateFormat(String date) {
        return date.matches("\\d{4}[0-1]\\d[0-3]\\d");
    }

    // Check if time is in HH:MM form
    public static boolean validateTimeFormat(String time) {
        return time.matches("(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]");
    }

    // Check if web is a valid URL
    public static boolean validateWebFormat(String web) {
        return web.matches("^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]");
    }

    // Check if phone number is valid
    public static boolean validatePhoneNumber(String phone) {
        return phone.matches("\\d{3}-\\d{3}-\\d{4}");
    }

    // Check if credit card number is valid
    public static boolean validateCreditCardNumber(String number) {
        return number.matches("\\d{16}");
    }

    // Check if credit card expiration date is valid
    public static boolean validateExpirationDate(String date) {
        if (!date.matches("\\d{2}/\\d{2}")) return false;

        int year = Integer.parseInt("20" + date.split("/")[1]);
        int month = Integer.parseInt(date.split("/")[0]);
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH) + 1;

        if (year < currentYear) return false;
        if (year == currentYear && month <= currentMonth) return false;
        return true;
    }

    public static Date buildDate(String date) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        return formatter.parse(date);
    }

    // Build error message to a json string
    public static String buildErrorJson(String errorMessage) {
        return "{\"error\":\"" + errorMessage + "\"}";
    }

    public static int getSectionPrice(ArrayList<Section> sections, String sectionId) {
        for (Section section : sections) {
            if (section.matchesId(sectionId))
                return section.getPrice();
        }

        return -1;
    }

    public static Response returnErrorResponse(Response.Status status, String errorMessage) {
        return Response.status(status).entity(prettyJson(buildErrorJson(errorMessage))).build();
    }

    // Print Json object pretty
    public static String prettyJson(String s) {
        return gson.toJson(gson.fromJson(s, Object.class));
    }

    public static boolean hasSection(ArrayList<Section> sections, Section section) {
        for (Section s : sections) {
            if (s.matchesId(section.getSectionId()))
                return true;
        }

        return false;
    }

    public static String formatOrderDate(Date orderDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return formatter.format(orderDate);
    }

    public static int getYear(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
        return Integer.parseInt(formatter.format(date));
    }

    public static int getMonth(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM");
        return Integer.parseInt(formatter.format(date));
    }

    public static int getDay(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd");
        return Integer.parseInt(formatter.format(date));
    }

    public static int getHour(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("HH");
        return Integer.parseInt(formatter.format(date));
    }

    public static int getMinute(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("mm");
        return Integer.parseInt(formatter.format(date));
    }

    // Write donation request info in this format
    /*
        "did": "759",
    	"wid": "308",
    	"count": 2,
    	"status": "pending",
    	"tickets": [],
    	"patron_info": {
    		"name": "John Smith",
    		"phone": "123-457-6890",
    		"email": "john.smith@example.com",
    		"billing_address": "123 Main ST, Anytown, CA 90999",
    		"cc_number": "1234567890985432",
    		"cc_expiration_date": "4/22"
    	}
    */
    public static void writeDonationRequestInfo(JsonWriter writer, DonationRequest request) throws IOException {
        String donationId = request.getDonationId();
        String showId = request.getShowId();
        int count = request.getCount();
        String status = request.getStatus();
        ArrayList<Ticket> tickets = request.getTickets();
        Patron patron = request.getPatron();
        
        writer.name("did").value(donationId);
        writer.name("wid").value(showId);
        writer.name("count").value(count);
        writer.name("status").value(status);
        writer.name("tickets").beginArray();
        for (Ticket t : tickets) {
            writer.value(t.getTicketId());
        }
        writer.endArray();

        CreditCard card = patron.getCreditCard();

        String patronName = patron.getName();
        String patronPhone = patron.getPhone();
        String patronEmail = patron.getEmail();
        String cardAddress = card.getBillingAddress();
        String cardNumber = card.getCardNumber();
        String expirationDate = card.getExpirationDate();

        writePatronInfo(writer, patronName, patronPhone, patronEmail, cardAddress, cardNumber, expirationDate);
    }

    // Write ticket info in this format
    /*
        "tid": "729",
    	"price": 60,
    	"status": "open"
    */
    public static void writeTicketInfoRaw(JsonWriter writer, String ticketId, int price, boolean used) throws IOException {
        writer.name("tid").value(ticketId);
        writer.name("price").value(price);
        writer.name("status").value(used ? "used" : "open");
    }

    // Write patron info in this format
    /*
        "patron_info": {
    		"name": "John Doe",
    		"phone": "123-456-7890",
    		"email": "john.doe@example.com",
    		"billing_address": "123 Main ST, Anytown, IL 45678",
    		"cc_number": "xxxxxxxxxxxx7654",
    		"cc_expiration_date": "12/21"
    	}
    */
    public static void writePatronInfo(JsonWriter writer, String name, String phone, String email, String address,
            String number, String date) throws IOException {
        writer.name("patron_info").beginObject();
        writer.name("name").value(name);
        writer.name("phone").value(phone);
        writer.name("email").value(email);
        writer.name("billing_address").value(address);
        writer.name("cc_number").value(number);
        writer.name("cc_expiration_date").value(date);
        writer.endObject();
    }

    // Write order info in this format
    /*
        "oid": "411",
    	"wid": "308",
    	"show_info": {
    		"name": "King Lear",
    		"web": "http://www.example.com/shows/king-lear",
    		"date": "2017-12-05",
    		"time": "13:00"
    	},
    	"date_ordered": "2017-10-28 18:24",
    	"order_amount": 180,
    */
    public static void writeOrderInfo(JsonWriter writer, String orderId, String showId, String name, String web,
            String date, String time, String dateOrdered, int amount) throws IOException {
        writer.name("oid").value(orderId);
        writeShowInfo(writer, showId, name, web, date, time);
        writer.name("date_ordered").value(dateOrdered);
        writer.name("order_amount").value(amount);
    }

    // Write ticket error info in this format
    /*
        "sid": "123",
    	"section_name": "Front right",
    	"starting_seat_id": "201",
    	"status": "Error: 5 contiguous seats not available",
    	"seating": []
    */
    public static void writeErrorTicket(JsonWriter writer, String sectionId, String sectionName, String startingSeatChairId,
            String status) throws IOException {
        writer.name("sid").value(sectionId);
        writer.name("section_name").value(sectionName);
        writer.name("starting_seat_id").value(startingSeatChairId);
        writer.name("status").value(status);
        writer.name("seating").beginArray();
        writer.endArray();
    }

    // Write ticket info in this format
    /*
        "sid": "123",
    	"section_name": "Front right",
    	"starting_seat_id": "201",
    	"status": "ok",
    	"total_amount": 180,
    	"seating": [{
    		"row": "1",
    		"seats": [{
    				"cid": "201",
    				"seat": "1",
    				"status": "available"
    			},
    			{
    				"cid": "202",
    				"seat": "2",
    				"status": "available"
    			},
    			{
    				"cid": "203",
    				"seat": "3",
    				"status": "available"
    			}
    		]
    	}]
    */
    public static void writeTicketInfo(JsonWriter writer, String sectionId, String sectionName, String startingSeatChairId,
            String status, int totalAmount, int row, ArrayList<Seat> seats) throws IOException {
        writer.name("sid").value(sectionId);
        writer.name("section_name").value(sectionName);
        writer.name("starting_seat_id").value(startingSeatChairId);
        writer.name("status").value(status);
        writer.name("total_amount").value(totalAmount);
        writer.name("seating").beginArray();
        writer.beginObject();
        writeSeatsInfo(writer, row, seats);
        writer.endObject();
        writer.endArray();
    }

    // Write show info in this format
    /*
            "wid": 308,
            "show_info": {
                "name": "King Lear",
                "web": "http://www.example.com/shows/king-lear",
                "date": "2017-12-05",
                "time": "13:00"
            }
    */
    public static void writeShowInfo(JsonWriter writer, String showId, String name, String web, String date, String time)
            throws IOException {
        writer.name("wid").value(showId);
        writer.name("show_info").beginObject();
        writer.name("name").value(name);
        writer.name("web").value(web);
        writer.name("date").value(date);
        writer.name("time").value(time);
        writer.endObject();
    }

    // Write seatings' info in this format
    /*
        "seating_info": [
            {
                "sid": 123,
                "price": 60
            },
            {
                "sid": 124,
                "price": 75
            },
            {
                "sid": 125,
                "price": 60
            }
        ]JsonReader reader = 
    */
    public static void writeSeatingsInfo(JsonWriter writer, ArrayList<Section> sections) throws IOException {
        writer.name("seating_info").beginArray();
        for (Section s : sections) {
            writeSeatingInfo(writer, s);
        }
        writer.endArray();
    }

    // Write a single seating's info in this format
    /*
        {
            "sid": 123
            "price": 60
        }
    */
    public static void writeSeatingInfo(JsonWriter writer, Section section) throws IOException {
        String sectionId = section.getSectionId();
        int price = section.getPrice();

        writer.beginObject();
        writer.name("sid").value(sectionId);
        writer.name("price").value(price);
        writer.endObject();
    }

    // Write section info in this format
    /*
        {
    		"sid": 124,
    		"section_name": "Front center",
    		"price": 75
    	}
    */
    public static void writeSectionInfo(JsonWriter writer, String sectionId, String sectionName, int price)
            throws IOException {
        writer.name("sid").value(sectionId);
        writer.name("section_name").value(sectionName);
        writer.name("price").value(price);
    }

    // Write section's seats' info as an array of seats' info, but without availability and other info
    public static void writeSectionSeatsInfoRaw(JsonWriter writer, ArrayList<ArrayList<Seat>> seats)
            throws IOException {
        writer.name("seating").beginArray();
        for (int i = 1; i <= seats.size(); ++i) {
            ArrayList<Seat> rowSeats = seats.get(i - 1);
            writer.beginObject();
            writeSeatsInfoRaw(writer, i, rowSeats);
            writer.endObject();
        }
        writer.endArray();
    }

    /*
        {
    		"row": "2",
    		"seats": [
    			"1",
    			"2",
    			"3",
    			"4"
    		]
    	}
    */
    public static void writeSeatsInfoRaw(JsonWriter writer, int row, ArrayList<Seat> seats) throws IOException {
        writer.name("row").value(Integer.toString(row));
        writer.name("seats").beginArray();
        for (Seat s : seats) {
            String seatNumber = s.getSeatNumber();
            writer.value(seatNumber);
        }
        writer.endArray();
    }

    // Write section's seats' info as an array of seats' info
    public static void writeSectionSeatsInfo(JsonWriter writer, ArrayList<ArrayList<Seat>> seats) throws IOException {
        writer.name("seating").beginArray();
        for (int i = 1; i <= seats.size(); ++i) {
            ArrayList<Seat> rowSeats = seats.get(i - 1);
            writer.beginObject();
            writeSeatsInfo(writer, i, rowSeats);
            writer.endObject();
        }
        writer.endArray();
    }

    // Write seats' info in this format
    /*
        {
    		"row": "1",
    		"seats": [
                {
    			    "cid": 201,
    				"seat": 1,
    				"status": "available"
    			},
    			{
    				"cid": 202,
    				"seat": 2,
    				"status": "available"
    			},
    			{
    				"cid": 203,
    				"seat": 3,
    				"status": "available"
    			},
    			{
    				"cid": 204,
    				"seat": 4,
    				"status": "sold"
    			}
    		]
    	}
    */
    public static void writeSeatsInfo(JsonWriter writer, int row, ArrayList<Seat> seats) throws IOException {
        writer.name("row").value(row);
        writer.name("seats").beginArray();
        for (Seat s : seats) {
            String charId = s.getCharId();
            String seatNumber = s.getSeatNumber();
            String status = s.isAvailable() ? "available" : "sold";

            writer.beginObject();
            writeSeatInfo(writer, charId, seatNumber, status);
            writer.endObject();
        }
        writer.endArray();
    }

    // Write a single seat's info in this format
    /*
        {
    		"cid": 202,
    		"seat": 2,
    		"status": "available"
    	}
    */
    public static void writeSeatInfo(JsonWriter writer, String charId, String seatNumber, String status) throws IOException {
        writer.name("cid").value(charId);
        writer.name("seat").value(seatNumber);
        writer.name("status").value(status);
    }
}