package edu.iit.hawk.cwu49;

import java.util.ArrayList;
import java.util.Date;

public class Order {
    private String orderId;
    private String showId;
    private Date date;
    private int amount;
    private ArrayList<Ticket> tickets;

    public Order() {
        this.orderId = null;
        this.showId = null;
        this.date = null;
        this.amount = 0;
        this.tickets = null;
    }

    public Order(String showId, Date date, int amount, ArrayList<Ticket> tickets) {
        this.orderId = HelperFunctions.getUniqueOrderId();
        this.showId = showId;
        this.date = date;
        this.amount = amount;
        this.tickets = tickets;
    }

    public void setShowId(String showId) {
        this.showId = showId;
    }

    public void setDate(Date d) {
        this.date = d;
    }

    public void setAmount(int a) {
        this.amount = a;
    }

    public void setTickets(ArrayList<Ticket> t) {
        this.tickets = t;
    }

    public String getOrderId() {
        return this.orderId;
    }

    public String getShowId() {
        return this.showId;
    }

    public Date getDate() {
        return this.date;
    }

    public int getAmount() {
        return this.amount;
    }

    public ArrayList<Ticket> getTickets() {
        return this.tickets;
    }

    public boolean isNil() {
        return false;
    }

    public boolean matchesId(String orderId) {
        return orderId.equals(this.orderId);
    }
}