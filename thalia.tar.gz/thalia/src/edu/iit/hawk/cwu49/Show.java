package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public class Show {
    private String showId; // wid
    private String name;
    private String web;
    private String date;
    private String time;
    private ArrayList<Section> sections;

    public Show() {
        this.showId = null;
        this.name = null;
        this.web = null;
        this.date = null;
        this.time = null;
        this.sections = null;
    }

    public Show(String name, String web, String date, String time, ArrayList<Section> sections) {
        this.showId = HelperFunctions.getUniqueShowId();
        this.name = name;
        this.web = web;
        this.date = date;
        this.time = time;
        this.sections = sections;
    }

    public void setShowId(String showId) {
        this.showId = showId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setSections(ArrayList<Section> sections) {
        this.sections = sections;
    }

    public String getShowId() {
        return this.showId;
    }

    public String getName() {
        return this.name;
    }

    public String getWeb() {
        return this.web;
    }

    public String getDate() {
        return this.date;
    }

    public String getTime() {
        return this.time;
    }

    public ArrayList<Section> getSections() {
        return this.sections;
    }

    public boolean isNil() {
        return false;
    }

    public boolean matchesId(String showId) {
        return showId.equals(this.showId);
    }
}