package edu.iit.hawk.cwu49;

public class CreditCard {
    private String cardNumber;
    private String expirationDate;
    private String billingAddress;

    public CreditCard() {
        this.cardNumber = null;
        this.expirationDate = null;
        this.billingAddress = null;
    }

    public CreditCard(String cardNumber, String expirationDate, String billingAddress) {
        this.cardNumber = cardNumber;
        this.expirationDate = expirationDate;
        this.billingAddress = billingAddress;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setExpirationDate(String date) {
        this.expirationDate = date;
    }

    public void setBillingAddress(String address) {
        this.billingAddress = address;
    }

    public String getCardNumber() {
        return this.cardNumber;
    }

    public String getExpirationDate() {
        return this.expirationDate;
    }

    public String getBillingAddress() {
        return this.billingAddress;
    }

    public boolean isNil() {
        return false;
    }

    public boolean matchesCardNumber(String cardNumber) {
        return cardNumber.equals(this.cardNumber);
    }
}