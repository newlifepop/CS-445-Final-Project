package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public class TicketManager implements TicketInterface {
    private static ArrayList<Ticket> tickets = new ArrayList<Ticket>();
    private static ArrayList<Ticket> donatedTickets = new ArrayList<Ticket>();

    @Override
    public Ticket addTicket(int price, boolean used, String showId, Patron patron, String sectionId, Seat seat) {
        Ticket t = new Ticket(price, used, showId, patron, sectionId, seat);
        tickets.add(t);
        return t;
    }

    @Override
    public ArrayList<Ticket> viewAllTickets() {
        return tickets;
    }

    @Override
    public Ticket viewTicket(String ticketId) {
        for (Ticket t : tickets) {
            if (t.matchesId(ticketId))
                return t;
        }

        return new NullTicket();
    }

    @Override
    public Ticket scanTicket(String ticketId) {
        Ticket ticket = viewTicket(ticketId);
        ticket.setUsed(true);
        return ticket;
    }

    @Override
    public ArrayList<Ticket> donateTickets(ArrayList<Ticket> tickets) {
        for (Ticket t : tickets) {
            donatedTickets.add(t);
        }

        return tickets;
    }

    @Override
    public void deleteTickets(String showId) {
        for (int i = 0; i < tickets.size(); ++i) {
            if (tickets.get(i).getShowId().equals(showId))
                tickets.remove(i);
        }

        for (int i = 0; i < donatedTickets.size(); ++i) {
            if (donatedTickets.get(i).getShowId().equals(showId))
                donatedTickets.remove(i);
        }
    }

    @Override
    public void deleteTicket(String ticketId) {
        for (int i = 0; i < tickets.size(); ++i) {
            if (tickets.get(i).matchesId(ticketId)) {
                tickets.remove(i);
                return;
            }
        }
    }
}