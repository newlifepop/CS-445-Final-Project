package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public interface SeatingInterface {
    // Read TheatreLayout.json file and create default sections
    ArrayList<Section> createDefaultTheatreLayout();
    ArrayList<Section> getTheatreLayout();
    Section getSection(String sectionId);
    ArrayList<Seat> getAllSeats();
    String getSectionName(String sectionId);
    ArrayList<ArrayList<Seat>> getSectionSeats(String sectionId);
    ArrayList<Seat> findContiguousSeats(Section section, int count, String startingSeatChairId);
    int getRowNumber(Section section, Seat seat);
}