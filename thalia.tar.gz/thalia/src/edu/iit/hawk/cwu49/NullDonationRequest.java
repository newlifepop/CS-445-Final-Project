package edu.iit.hawk.cwu49;

public class NullDonationRequest extends DonationRequest {
    @Override
    public boolean isNil() {
        return true;
    }
}