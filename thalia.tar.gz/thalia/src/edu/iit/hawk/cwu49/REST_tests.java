package edu.iit.hawk.cwu49;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class REST_tests {
	ShowInterface showManager;
	SeatingInterface seatingManager;
	TicketInterface ticketManager;
	OrderInterface orderManager;
	DonationInterface donationRequestManager;

	private ArrayList<Section> theatreLayout = new ArrayList<Section>();

	@Before
	public void setUp() throws Exception {
		showManager = new ShowManager();
		seatingManager = new SeatingManager();
		ticketManager = new TicketManager();
		orderManager = new OrderManager();
		donationRequestManager = new DonationManager();

		theatreLayout = seatingManager.createDefaultTheatreLayout();
	}

	@Test
	public void test_new_show_created() {
		String name = "King Lear";
		String web = "http://example.com/King_Lear";
		String date = "2017-11-23";
		String time = "22:02";

		ArrayList<Section> sections = new ArrayList<Section>();

		Show show = showManager.createShow(name, web, date, time, sections);
		String showId = show.getShowId();

		assertTrue(hasShow(showManager.viewAllShows(), showId));
	}

	@Test
	public void test_multiple_shows_created() {
		String name = "King Lear";
		String web = "http://example.com/King_Lear";
		String date = "2017-11-23";
		String time = "22:02";

		ArrayList<Section> sections = new ArrayList<Section>();

		for (int i = 0; i < 100; ++i) {
			Show show = showManager.createShow(name, web, date, time, sections);
			String showId = show.getShowId();

			assertTrue(hasShow(showManager.viewAllShows(), showId));
		}
	}

	@Test
	public void test_show_does_not_exist() {
		assertFalse(hasShow(showManager.viewAllShows(), "csc"));
	}

	@Test
	public void test_updated_show_not_equal() {
		Show targetShow = showManager.viewAllShows().get(0);
		String showId = targetShow.getShowId();
		String name = targetShow.getName();
		String web = targetShow.getWeb();
		String date = targetShow.getDate();
		String time = targetShow.getTime();
		ArrayList<Section> sections = targetShow.getSections();

		Show updatedShow = showManager.updateShow(showId, name, web, date, time, sections);
		assertTrue(showEquals(targetShow, updatedShow));
	}

	@Test
	public void test_default_theatre_layout() {
		int total = 0;
		for (Section section : theatreLayout) {
			total += getSectionNumberOfSeats(section);
		}

		assertTrue(theatreLayout.size() == 6);
		assertTrue(total == 102);
	}

	@Test
	public void test_show_section_is_available() {
		// sections 123 - 128 are available, nothing else is
		for (int i = 0; i < 200; ++i) {
			String sectionId = Integer.toString(i);
			if (sectionId.equals("123") ||
					sectionId.equals("124") ||
					sectionId.equals("125") ||
					sectionId.equals("126") ||
					sectionId.equals("127") ||
					sectionId.equals("128")) {
				assertTrue(hasSection(theatreLayout, sectionId));
			} else {
				assertFalse(hasSection(theatreLayout, sectionId));
			}
		}
	}
	
	@Test
	public void test_seating_section_name() {
		for (Section section : theatreLayout) {
			switch (section.getSectionId()) {
			case "123":
				assertTrue(section.getSectionName().equals("Front right"));
				break;
			case "124":
				assertTrue(section.getSectionName().equals("Front center"));
				break;
			case "125":
				assertTrue(section.getSectionName().equals("Front left"));
				break;
			case "126":
				assertTrue(section.getSectionName().equals("Main right"));
				break;
			case "127":
				assertTrue(section.getSectionName().equals("Main center"));
				break;
			case "128":
				assertTrue(section.getSectionName().equals("Main left"));
				break;
			default:
				assertTrue(1 == 2);	// Anything else should fail the test
									// because no other section id is allowed
			}
		}
	}
	
	@Test
	public void test_section_number_of_seats() {
		for (Section section : theatreLayout) {
			switch (section.getSectionId()) {
			case "123":
				assertTrue(getSectionNumberOfSeats(section) == 16);
				break;
			case "124":
				assertTrue(getSectionNumberOfSeats(section) == 19);
				break;
			case "125":
				assertTrue(getSectionNumberOfSeats(section) == 16);
				break;
			case "126":
				assertTrue(getSectionNumberOfSeats(section) == 15);
				break;
			case "127":
				assertTrue(getSectionNumberOfSeats(section) == 21);
				break;
			case "128":
				assertTrue(getSectionNumberOfSeats(section) == 15);
				break;
			default:
				assertTrue(1 == 2);	// Anything else should fail the test
									// because no other section id is allowed
			}
		}
	}
	
	@Test
	public void test_ticket_created() {
		Ticket ticket = ticketManager.addTicket(0, false, null, null, null, null);
		assertFalse(hasTicket(ticketManager.viewAllTickets(), "000"));
		assertTrue(hasTicket(ticketManager.viewAllTickets(), ticket.getTicketId()));
	}
	
	@Test
	public void test_order_created() {
		Order order = orderManager.createOrder(null, null, 0, null);
		assertFalse(hasOrder(orderManager.viewAllOrders(), "000"));
		assertTrue(hasOrder(orderManager.viewAllOrders(), order.getOrderId()));
	}
	
	private boolean hasOrder(ArrayList<Order> orders, String orderId) {
		for (Order order : orders) {
			if (order.matchesId(orderId))
				return true;
		}
		
		return false;
	}
	
	private boolean hasTicket(ArrayList<Ticket> tickets, String ticketId) {
		for (Ticket ticket : tickets) {
			if (ticket.matchesId(ticketId))
				return true;
		}
		
		return false;
	}

	private boolean hasSection(ArrayList<Section> sections, String sectionId) {
		for (Section s : sections) {
			if (s.matchesId(sectionId))
				return true;
		}

		return false;
	}

	private int getSectionNumberOfSeats(Section section) {
		ArrayList<ArrayList<Seat>> seats = section.getSeats();
		int total = 0;

		for (ArrayList<Seat> rowSeats : seats) {
			total += rowSeats.size();
		}

		return total;
	}

	private boolean showEquals(Show show1, Show show2) {
		return show1.getShowId().equals(show2.getShowId()) && show2.getTime().equals(show1.getTime())
				&& show1.getWeb().equals(show2.getWeb()) && show1.getSections().equals(show2.getSections())
				&& show1.getName().equals(show2.getName()) && show1.getDate().equals(show2.getDate());
	}

	private boolean hasShow(ArrayList<Show> shows, String showId) {
		for (Show s : shows) {
			if (s.matchesId(showId))
				return true;
		}

		return false;
	}
}