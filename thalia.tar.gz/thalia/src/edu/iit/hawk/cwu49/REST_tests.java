package edu.iit.hawk.cwu49;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class REST_tests {
	ShowInterface showManager;
	SeatingInterface seatingManager;
	TicketInterface ticketManager;
	OrderInterface orderManager;
	DonationInterface donationRequestManager;
	
	private ArrayList<Section> theatreLayout = new ArrayList<Section>();
	
	@Before
	public void setUp() throws Exception {
		showManager = new ShowManager();
		seatingManager = new SeatingManager();
		ticketManager = new TicketManager();
		orderManager = new OrderManager();
		donationRequestManager = new DonationManager();
		
		theatreLayout = seatingManager.createDefaultTheatreLayout();
	}
	
	@Test
	public void test_new_show_created() {
		String name = "King Lear";
		String web = "http://example.com/King_Lear";
		String date = "2017-11-23";
		String time = "22:02";
		
		ArrayList<Section> sections = new ArrayList<Section>();
		
		Show show = showManager.createShow(name, web, date, time, sections);
		String showId = show.getShowId();
		
		assertTrue(hasShow(showManager.viewAllShows(), showId));
	}
	
	@Test
	public void test_multiple_shows_created() {
		String name = "King Lear";
		String web = "http://example.com/King_Lear";
		String date = "2017-11-23";
		String time = "22:02";
		
		ArrayList<Section> sections = new ArrayList<Section>();
		
		for (int i = 0; i < 100; ++i) {
			Show show = showManager.createShow(name, web, date, time, sections);
			String showId = show.getShowId();
			
			assertTrue(hasShow(showManager.viewAllShows(), showId));
		}
	}
	
	@Test
	public void test_show_does_not_exist() {
		assertFalse(hasShow(showManager.viewAllShows(), "csc"));
	}
	
	@Test
	public void test_updated_show_not_equal() {
		Show targetShow = showManager.viewAllShows().get(0);
		String showId = targetShow.getShowId();
		String name = targetShow.getName();
		String web = targetShow.getWeb();
		String date = targetShow.getDate();
		String time = targetShow.getTime();
		ArrayList<Section> sections = targetShow.getSections();
		
		Show updatedShow = showManager.updateShow(showId, name, web, date, time, sections);
		assertTrue(showEquals(targetShow, updatedShow));
	}
	
	@Test
	public void test_default_theatre_layout() {
		int total = 0;
		for (Section section : theatreLayout) {
			total += getSectionNumberOfSeats(section);
		}
		
		assertTrue(total == 102);
	}
	
	private int getSectionNumberOfSeats(Section section) {
		ArrayList<ArrayList<Seat>> seats = section.getSeats();
		int total = 0;
		
		for (ArrayList<Seat> rowSeats : seats) {
			total += rowSeats.size();
		}
		
		return total;
	}
	
	private boolean showEquals(Show show1, Show show2) {
		return show1.getShowId().equals(show2.getShowId()) &&
				show2.getTime().equals(show1.getTime()) &&
				show1.getWeb().equals(show2.getWeb()) &&
				show1.getSections().equals(show2.getSections()) &&
				show1.getName().equals(show2.getName()) &&
				show1.getDate().equals(show2.getDate());
	}
	
	private boolean hasShow(ArrayList<Show> shows, String showId) {
		for (Show s : shows) {
			if (s.matchesId(showId))
				return true;
		}
		
		return false;
	}
}