package edu.iit.hawk.cwu49;

public class NullCreditCard extends CreditCard {
    @Override
    public boolean isNil() {
        return true;
    }
}