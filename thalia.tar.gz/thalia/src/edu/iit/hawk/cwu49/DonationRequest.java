package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public class DonationRequest {
    private String donationId;  // did
    private String showId;
    private int count;
    private Patron patron;
    private String status;
    private ArrayList<Ticket> tickets;

    public DonationRequest() {
        this.donationId = null;
        this.showId = null;
        this.count = 0;
        this.patron = null;
        this.status = null;
        this.tickets = null;
    }

    public DonationRequest(String showId, int count, Patron patron) {
        this.donationId = HelperFunctions.getUniqueDonationId();
        this.showId = showId;
        this.count = count;
        this.patron = patron;
        this.status = "pending";
        this.tickets = new ArrayList<Ticket>();
    }

    public ArrayList<Ticket> getTickets() {
        return this.tickets;
    }

    public String getDonationId() {
        return this.donationId;
    }

    public String getShowId() {
        return this.showId;
    }

    public int getCount() {
        return this.count;
    }

    public Patron getPatron() {
        return this.patron;
    }

    public String getStatus() {
        return this.status;
    }

    public void setDonationId(String donationId) {
        this.donationId = donationId;
    }

    public void setShowId(String showId) {
        this.showId = showId;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setPatron(Patron patron) {
        this.patron = patron;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTickets(ArrayList<Ticket> tickets) {
        this.tickets = tickets;
    }

    public boolean matchesId(String donationId) {
        return this.donationId.equals(donationId);
    }

    public boolean isNil() {
        return false;
    }
}