package edu.iit.hawk.cwu49;

import java.util.ArrayList;
import java.util.Date;

public interface OrderInterface {
    Order createOrder(String showId, Date date, int amount, ArrayList<Ticket> tickets);
    ArrayList<Order> viewAllOrders();
    Order viewOrder(String orderId);
    ArrayList<Order> viewOrderByDate(Date startDate, Date endDate);
    void updateTicketStatus(String ticketId, boolean used);
    void deleteOrders(String showId);
    void deleteOrder(String orderId);
}