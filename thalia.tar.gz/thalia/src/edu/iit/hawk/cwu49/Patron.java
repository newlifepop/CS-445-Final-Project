package edu.iit.hawk.cwu49;

public class Patron {
    private String name;
    private String phone;
    private String email;
    private CreditCard creditCard;

    public Patron() {
        this.name = null;
        this.phone = null;
        this.email = null;
        this.creditCard = null;
    }

    public Patron(String name, String phone, String email, CreditCard creditCard) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.creditCard = creditCard;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCreditCard(CreditCard card) {
        this.creditCard = card;
    }

    public String getName() {
        return this.name;
    }

    public String getPhone() {
        return this.phone;
    }

    public String getEmail() {
        return this.email;
    }

    public CreditCard getCreditCard() {
        return this.creditCard;
    }

    public boolean isNil() {
        return false;
    }

    public boolean matchesEmail(String email) {
        return this.email.equals(email);
    }
}