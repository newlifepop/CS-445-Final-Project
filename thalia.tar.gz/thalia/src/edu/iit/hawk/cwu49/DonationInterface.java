package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public interface DonationInterface {
    ArrayList<DonationRequest> viewAllDonationRequests();
    DonationRequest viewDonationRequest(String donationId);
    DonationRequest createDonationRequest(String showId, int count, Patron patron);
}