package edu.iit.hawk.cwu49;

public class Seat {
    private String charId; // cid
    private String seatNumber; // seat
    private boolean available; // sold or unavailable

    public Seat() {
        this.charId = null;
        this.seatNumber = null;
        this.available = false;
    }

    public Seat(String charId, String seatNumber, boolean available) {
        this.charId = charId;
        this.seatNumber = seatNumber;
        this.available = available;
    }

    public String getCharId() {
        return this.charId;
    }

    public String getSeatNumber() {
        return this.seatNumber;
    }

    public boolean isAvailable() {
        return this.available;
    }

    public void setCharId(String charId) {
        this.charId = charId;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public void setAvailability(boolean available) {
        this.available = available;
    }

    public boolean matchesId(String charId) {
        return charId.equals(this.charId);
    }

    public boolean isNil() {
        return false;
    }
}