package edu.iit.hawk.cwu49;

import java.util.ArrayList;
import java.util.Date;

public class OrderManager implements OrderInterface {
    private static ArrayList<Order> orders = new ArrayList<Order>();

	@Override
	public Order createOrder(String showId, Date date, int amount, ArrayList<Ticket> tickets) {
		Order o = new Order(showId, date, amount, tickets);
		orders.add(o);
		return o;
	}

	@Override
	public ArrayList<Order> viewAllOrders() {
		return orders;
	}

	@Override
	public Order viewOrder(String orderId) {
		for (Order o : orders) {
			if (o.matchesId(orderId))
				return o;
		}

		return new NullOrder();
	}

	@Override
	public ArrayList<Order> viewOrderByDate(Date startDate, Date endDate) {
		ArrayList<Order> result = new ArrayList<Order>();

		for (Order order : orders) {
			Date dateCreated = order.getDate();
			if (dateCreated.compareTo(startDate) < 0) continue;
			if (dateCreated.compareTo(endDate) > 0) continue;
			result.add(order);
		}

		return result;
	}

	@Override
	public void updateTicketStatus(String ticketId, boolean used) {
		int orderIndex = findOrderIndex(ticketId);
		Order order = orders.get(orderIndex);
		ArrayList<Ticket> tickets = order.getTickets();
		int ticketIndex = findTicketIndex(tickets, ticketId);
		Ticket ticket = tickets.get(ticketIndex);
		
		ticket.setUsed(used);
		tickets.set(ticketIndex, ticket);
		order.setTickets(tickets);
		orders.set(orderIndex, order);
	}

	private int findOrderIndex(String ticketId) {
		for (int i = 0; i < orders.size(); ++i) {
			Order order = orders.get(i);
			ArrayList<Ticket> tickets = order.getTickets();
			for (Ticket t : tickets) {
				if (t.matchesId(ticketId))
					return i;
			}
		}
		
		return -1;
	}
	
	private int findTicketIndex(ArrayList<Ticket> tickets, String ticketId) {
		for (int i = 0; i < tickets.size(); ++i) {
			if (tickets.get(i).matchesId(ticketId)) {
				return i;
			}
		}
		
		return -1;
	}
}




















