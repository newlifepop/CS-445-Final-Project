package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public class DonationManager implements DonationInterface {
    private static ArrayList<DonationRequest> donationRequests = new ArrayList<DonationRequest>();

	@Override
	public ArrayList<DonationRequest> viewAllDonationRequests() {
		return donationRequests;
	}

	@Override
	public DonationRequest viewDonationRequest(String donationId) {
		for (DonationRequest d : donationRequests) {
            if (d.matchesId(donationId))
                return d;
        }

        return new NullDonationRequest();
	}

	@Override
	public DonationRequest createDonationRequest(String showId, int count, Patron patron) {
		DonationRequest request = new DonationRequest(showId, count, patron);
		donationRequests.add(request);
		return request;
	}
}