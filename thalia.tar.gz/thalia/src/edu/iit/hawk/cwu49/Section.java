package edu.iit.hawk.cwu49;

import java.util.ArrayList;

public class Section {
    private String sectionId; // sid
    private String sectionName; // "Front right", "Front left", etc
    private int price;
    private ArrayList<ArrayList<Seat>> seats;

    public Section() {
        this.sectionId = null;
        this.sectionName = null;
        this.price = 0;
        this.seats = null;
    }

    public Section(String sectionId, String sectionName, int price, ArrayList<ArrayList<Seat>> seats) {
        this.sectionId = sectionId;
        this.sectionName = sectionName;
        this.price = price;
        this.seats = seats;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setSeats(ArrayList<ArrayList<Seat>> seats) {
        this.seats = seats;
    }

    public String getSectionId() {
        return this.sectionId;
    }

    public String getSectionName() {
        return this.sectionName;
    }

    public int getPrice() {
        return this.price;
    }

    public ArrayList<ArrayList<Seat>> getSeats() {
        return this.seats;
    }

    // Helper
    public int numberOfSeats() {
        int total = 0;
        for (ArrayList<Seat> row : this.seats)
            total += row.size();

        return total;
    }

    public boolean matchesId(String sectionId) {
        return sectionId.equals(this.sectionId);
    }

    public boolean isNil() {
        return false;
    }
}