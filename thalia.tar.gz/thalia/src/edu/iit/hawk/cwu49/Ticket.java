package edu.iit.hawk.cwu49;

public class Ticket {
    private String ticketId;
    private int price;
    private boolean used;
    private String showId;
    private Patron patron;
    private String sectionId;
    private Seat seat;

    public Ticket() {
        this.ticketId = null;
        this.price = 0;
        this.used = false;
        this.showId = null;
        this.patron = null;
        this.sectionId = null;
        this.seat = null;
    }

    public Ticket(int price, boolean used, String showId, Patron patron, String sectionId, Seat seat) {
        this.ticketId = HelperFunctions.getUniqueTicketId();
        this.price = price;
        this.used = used;
        this.patron = patron;
        this.showId = showId;
        this.sectionId = sectionId;
        this.seat = seat;
    }

    public void setPrice(int p) {
        this.price = p;
    }

    public void setUsed(boolean used) {
        this.used = used;
    }

    public void setShowId(String s) {
        this.showId = s;
    }

    public void setPatron(Patron p) {
        this.patron = p;
    }

    public void setSectionId(String s) {
        this.sectionId = s;
    }

    public void setSeat(Seat s) {
        this.seat = s;
    }

    public String getTicketId() {
        return this.ticketId;
    }

    public int getPrice() {
        return this.price;
    }

    public boolean isUsed() {
        return this.used;
    }

    public String getShowId() {
        return this.showId;
    }

    public Patron getPatron() {
        return this.patron;
    }

    public String getSectionId() {
        return this.sectionId;
    }

    public Seat getSeat() {
        return this.seat;
    }

    public boolean matchesId(String id) {
        return id.equals(this.ticketId);
    }

    public boolean isNil() {
        return false;
    }
}